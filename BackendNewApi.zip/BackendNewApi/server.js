const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
require("dotenv").config();

const adminRoutes = require('./routes/adminRoutes');
const faqRoutes = require('./routes/faqRoutes');
const agentRoutes = require('./routes/agentRoutes');
const whatsappRoutes = require("./routes/whatsappRoutes"); // Import WhatsApp routes
const chatRoutes = require("./routes/chatRoutes");

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// CORS Options - Allowing specific methods (POST, GET, PUT, DELETE) from localhost:3000
const corsOptions = {
  origin: 'http://localhost:3000', // The allowed origin
  methods: ['GET', 'POST', 'PUT', 'DELETE'], // Allow only GET, POST, PUT, DELETE requests
  allowedHeaders: ['Content-Type', 'Authorization'], // Allow these headers
};

app.use(cors(corsOptions)); // Apply CORS with options

// Middleware to parse JSON
app.use(bodyParser.json());

// MongoDB connection
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.error('MongoDB connection error:', err));

// Routes
app.use('/api/auth', adminRoutes); // Admin auth and CRUD routes
app.use(faqRoutes); 
app.use(agentRoutes);

app.use("/api", chatRoutes);
app.use('/whatsapp', whatsappRoutes); // This will match /whatsapp/webhook for WhatsApp integration

// Starting the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
