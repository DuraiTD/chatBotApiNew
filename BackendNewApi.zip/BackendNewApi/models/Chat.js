const mongoose = require('mongoose');

const chatSchema = new mongoose.Schema({
    clientNumber: { type: String, required: true, unique: true },
    clientName: { type: String, required: true },
    messages: [{
        sender: { type: String, required: true },  // Sender name
        message: { type: String, required: true },  // Message text
        timestamp: { type: Date, default: Date.now }  // Message timestamp
    }]
});

module.exports = mongoose.model('Chat', chatSchema);
