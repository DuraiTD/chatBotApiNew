const mongoose = require('mongoose');

const clientSchema = new mongoose.Schema({
  client_id: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  phone: { type: String, required: true },
  assigned_agent: { type: String, required: true },
  assigned_team: { type: String, required: true },
  status: { type: String, default: 'Active' },
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now },
});

const Client = mongoose.model('Client', clientSchema);
module.exports = Client;
