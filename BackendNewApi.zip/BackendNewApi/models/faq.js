// models/Faq.js
const mongoose = require('mongoose');

// Define a schema for the FAQ model
const faqSchema = new mongoose.Schema({
  question: { type: String, required: true },
  answer: { type: String, required: true },
  questionType: { 
    type: String, 
    enum: [
      'text', 'yesno', 'button', 'checkbox', 'dropdown', 'date', 
      'rating', 'file', 'slider', 'card', 'quickreply'
    ], 
    default: 'text' 
  },
  options: { type: [String], default: [] }, // For dropdown, button, checkbox, etc.
  isRequired: { type: Boolean, default: false }, // Whether the answer is required
  minValue: { type: Number }, // For slider/rating min value
  maxValue: { type: Number }, // For slider/rating max value
  isFileRequired: { type: Boolean, default: false }, // For file upload type
});

// Create a FAQ model based on the schema
const Faq = mongoose.model('Faq', faqSchema);

module.exports = Faq;
