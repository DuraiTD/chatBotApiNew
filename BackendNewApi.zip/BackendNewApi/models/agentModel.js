const mongoose = require('mongoose');

 
const agentSchema = new mongoose.Schema({
  agent_id: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },   
  status: { type: String, default: 'Active' },
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now },
});

const Agent = mongoose.model('Agent', agentSchema);
module.exports = Agent;


 