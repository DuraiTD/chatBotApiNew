// Import the Agent model
const Agent = require('../models/agentModel');



exports.createAgent = async (req, res) => {
  try {
    const { agent_id, name, email, password, role } = req.body;

    // Validate required fields
    if (!agent_id || !name || !email || !password || !role) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    // Check if agent already exists
    const existingAgent = await Agent.findOne({ email });
    if (existingAgent) {
      return res.status(400).json({ message: 'Agent already exists' });
    }

    // Create new agent instance
    const newAgent = new Agent({
      agent_id,
      name,
      email,
      password,  // Ensure password is hashed before saving
      role,
      status: 'Active',
    });

    // Save the new agent in the database
    await newAgent.save();

    // Send a success response
    res.status(201).json({
      message: 'Agent created successfully',
      agent: {
        agent_id: newAgent.agent_id,
        name: newAgent.name,
        email: newAgent.email,
        role: newAgent.role,
        status: newAgent.status,
      },
    });
  } catch (error) {
    console.error('Error creating agent:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};
