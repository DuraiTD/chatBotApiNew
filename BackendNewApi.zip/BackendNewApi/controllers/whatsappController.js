const Twilio = require('twilio');
const { getChatResponse } = require('./faqController');
const Chat = require("../models/Chat");

const twilioSID = " ";  // Twilio SID
const twilioAuthToken = " ";  // Twilio Auth Token
const twilioPhoneNumber = "";  // Twilio Sandbox WhatsApp number

const client = new Twilio(twilioSID, twilioAuthToken);

// Function to send the main menu
async function sendMainMenu(sender) {
    await client.messages.create({
        from: `whatsapp:${twilioPhoneNumber}`,
        to: sender,
        body: "Main Menu:\n1️⃣ Learn Trading\n2️⃣ Deposit Funds\n3️⃣ Contact Support\n4️⃣ Return to Main Menu",
    });
}

// Handle the incoming WhatsApp webhook
exports.handleWhatsAppWebhook = async (req, res) => {
    try {
        console.log("📩 Incoming WhatsApp Webhook:", req.body);

        const message = req.body.Body.trim();
        const sender = req.body.From;
        const profileName = req.body.ProfileName || "Client"; // Use ProfileName as clientName

        if (!message || !sender) {
            console.error("❌ Missing message or sender");
            return res.status(400).json({ error: "Missing message or sender" });
        }

        // Normalize sender number (remove "whatsapp:")
        const clientNumber = sender.replace("whatsapp:", "");

        // Save the incoming message to the Chat schema
        const chatEntry = {
            clientNumber,
            clientName: profileName, // Store profileName as clientName
            messages: [
                {
                    sender: profileName,  // Store ProfileName as sender
                    message: message,
                    timestamp: new Date(),
                },
            ],
        };

        // Check if chat exists for the clientNumber, if yes, update messages, otherwise create new entry
        let chat = await Chat.findOne({ clientNumber });
        if (chat) {
            chat.messages.push(chatEntry.messages[0]);  // Append new message to existing chat
        } else {
            // Create new chat entry if not found
            chat = await Chat.create(chatEntry);
        }

        // 1️⃣ Handle Greeting (Hi/Hello)
        if (/hi|hello/i.test(message)) {
            const welcomeMessage = `🌟 *Welcome to POEMS Trading!* 🌟
Thank you for choosing Phillips Securities. Here’s why traders love POEMS:

✅ Trusted by thousands of investors  
✅ Easy-to-use trading platform  
✅ 24/7 customer support for all your needs  

📢 *Join our Telegram group for latest updates & insights:*  
👉 [https://t.me/poemstrading](https://t.me/poemstrading)

Here are some options to get started:`;

            // Send the welcome message to the client
            await client.messages.create({
                from: `whatsapp:${twilioPhoneNumber}`,
                body: welcomeMessage,
                to: sender,
            });

            // Store the welcome message in the chat history
            chat.messages.push({
                sender: "POEMSBOT",  // Store "POEMSBOT" as the bot's response
                message: welcomeMessage,
                timestamp: new Date(),
            });

            // Show the main menu
            await sendMainMenu(sender);

            await chat.save();  // Save the chat with the bot's welcome message
            return res.status(200).send("<Response></Response>");
        }

        // 2️⃣ Handle user selecting a number (1, 2, 3, etc.) for FAQ
        const faqMapping = {
            "1": "How to learn trading?",
            "2": "How to deposit funds into my trading account?",
            "3": "How to contact customer support?"
        };

        let botResponse = "";

        if (faqMapping[message]) {
            botResponse = await getChatResponse(faqMapping[message]);

            // Send the FAQ response
            await client.messages.create({
                from: `whatsapp:${twilioPhoneNumber}`,
                body: `POEMSBOT: ${botResponse.answer}`,
                to: sender,
            });

            // Store the FAQ response
            chat.messages.push({
                sender: profileName,
                message: faqMapping[message],  // Store the FAQ number instead of the text
                timestamp: new Date(),
            });

            chat.messages.push({
                sender: "POEMSBOT",  // Store "POEMSBOT" as the bot's response
                message: botResponse.answer,
                timestamp: new Date(),
            });

            await chat.save();  // Save the chat record with the messages

            // Ask if they need more help
            await askForMoreHelp(sender);
            return res.status(200).send("<Response></Response>");
        }

        // 3️⃣ Handle "4" for returning to the main menu
        if (message === "4") {
            await sendMainMenu(sender);
            return res.status(200).send("<Response></Response>");
        }

        // 4️⃣ Handle "yes" or "no" after an FAQ answer
        if (/yes|menu|help/i.test(message)) {
            await sendMainMenu(sender);
            return res.status(200).send("<Response></Response>");
        } else if (/no|exit|bye/i.test(message)) {
            await client.messages.create({
                from: `whatsapp:${twilioPhoneNumber}`,
                body: "Thank you for contacting POEMS! Have a great day! 😊",
                to: sender,
            });
            return res.status(200).send("<Response></Response>");
        }

        // 5️⃣ Handle Normal FAQ Queries
        const response = await getChatResponse(message);

        if (!response || !response.answer) {
            console.error("❌ No valid response found.");
            return res.status(400).json({ error: "No valid response found." });
        }

        // Store normal FAQ response
        chat.messages.push({
            sender: profileName,
            message: message,
            timestamp: new Date(),
        });

        chat.messages.push({
            sender: "POEMSBOT",  // Store "POEMSBOT" as the bot's response
            message: response.answer,
            timestamp: new Date(),
        });

        await chat.save();  // Save the chat record with the messages

        await client.messages.create({
            from: `whatsapp:${twilioPhoneNumber}`,
            body: `POEMSBOT: ${response.answer}`,
            to: sender,
        });

        res.set("Content-Type", "text/xml");
        return res.status(200).send("<Response></Response>");
    } catch (error) {
        console.error("❌ Error processing WhatsApp message:", error);
        return res.status(500).json({ status: "error", message: "Internal Server Error" });
    }
};

// Function to ask if the user wants more help
async function askForMoreHelp(sender) {
    await client.messages.create({
        from: `whatsapp:${twilioPhoneNumber}`,
        to: sender,
        body: "Would you like more help?\nType 'YES' for the main menu or 'NO' to exit.",
    });
}
