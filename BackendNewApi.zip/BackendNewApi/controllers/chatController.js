const Chat = require("../models/Chat");

exports.getChatHistory = async (req, res) => {
  try {
    const { clientNumber } = req.params;
    const chat = await Chat.findOne({ clientNumber });

    if (!chat) return res.status(404).json({ error: "Chat not found" });

    res.json(chat);
  } catch (error) {
    console.error("❌ Error fetching chat history:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};
