// controllers/faqController.js
const Faq = require('../models/Faq');
// Import your actual FAQ model (e.g., ChatFAQ or something else)
const ChatFAQ = require('../models/ChatFAQ');  // Adjust path if necessary
// Update the name here


// Fetch all FAQs
exports.getAllFaqs = async (req, res) => {
  try {
    const faqs = await Faq.find();
    res.status(200).json(faqs);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching FAQs', error });
  }
};

// Add a new FAQ
exports.addFaq = async (req, res) => {
  const { question, answer, questionType, options, isRequired, minValue, maxValue, isFileRequired } = req.body;

  const newFaq = new Faq({
    question,
    answer,
    questionType,
    options,
    isRequired,
    minValue,
    maxValue,
    isFileRequired,
  });

  try {
    const savedFaq = await newFaq.save();
    res.status(201).json(savedFaq);
  } catch (error) {
    res.status(500).json({ message: 'Error saving FAQ', error });
  }
};

// Update an existing FAQ
exports.updateFaq = async (req, res) => {
  const { question, answer, questionType, options, isRequired } = req.body;

  try {
    const updatedFaq = await Faq.findByIdAndUpdate(
      req.params.id,
      { question, answer, questionType, options, isRequired },
      { new: true }
    );
    if (!updatedFaq) {
      return res.status(404).json({ message: 'FAQ not found' });
    }
    res.status(200).json(updatedFaq);
  } catch (error) {
    res.status(500).json({ message: 'Error updating FAQ', error });
  }
};

// Delete a FAQ
exports.deleteFaq = async (req, res) => {
  try {
    const deletedFaq = await Faq.findByIdAndDelete(req.params.id);
    if (!deletedFaq) {
      return res.status(404).json({ message: 'FAQ not found' });
    }
    res.status(200).json({ message: 'FAQ deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting FAQ', error });
  }
};

 
 


// Function to fetch the FAQ response
exports.getChatResponse = async (query) => {
  try {
    const faq = await Faq.findOne({
      question: { $regex: query, $options: 'i' }, // Case-insensitive search
    });

    if (!faq) {
      return { answer: "Sorry, I couldn't understand that. Can you ask something else?", questionType: null };
    }

    return { answer: faq.answer, questionType: faq.questionType, options: faq.options || [] };
  } catch (error) {
    console.error("❌ Error fetching FAQ response:", error);
    return { answer: "Sorry, I couldn't process your request.", questionType: null };
  }
};

 




