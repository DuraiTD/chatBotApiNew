const User = require('../models/userModel');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

// Admin login handler
const adminLogin = async (req, res) => {
    const { email, password } = req.body;
  
    console.log('Email:', email);
    console.log('Password:', password);
  
    try {
      // Find admin by email and role
      const admin = await User.findOne({ email, role: 'admin' });
  
      if (!admin) {
        return res.status(400).json({ message: 'Admin not found or invalid credentials' });
      }
  
      // Direct comparison (insecure: passwords should never be stored as plain text)
      if (admin.password === password) {
        // Generate JWT Token
        const token = jwt.sign(
          { user_id: admin._id, role: admin.role },
          process.env.JWT_SECRET,  // Ensure this is set in your environment variables
          { expiresIn: '1h' }
        );
  
        res.json({ token });
      } else {
        return res.status(400).json({ message: 'Invalid credentials' });
      }
  
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: 'Login failed' }); // Generic error message for security
    }
  };
  



 

const createAdmin = async (req, res) => {
  const { admin_id, name, email, password, role } = req.body;

  try {
    // Check if the admin already exists
    const adminExists = await User.findOne({ email });
    if (adminExists) {
      return res.status(400).json({ message: 'Admin already exists with this email' });
    }

    // Hash the password at the controller level
  
    // Create new admin instance
    const newUser = new User({
      admin_id,
      name,
      email,
      password,  // Save hashed password
      role,
      status: 'Active',
    });

    // Save the new admin in the database
    await newUser.save();

    // Send a success response
    res.status(201).json({
      message: 'Admin created successfully',
      admin: {
        admin_id: newUser.admin_id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        status: newUser.status,
      },
    });
  } catch (error) {
    console.error('Error creating admin:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};









// Get all Admins (For Admin CRUD operations)
const getAdmins = async (req, res) => {
  try {
    const admins = await User.find({ role: 'admin' });
    res.json(admins);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching admins' });
  }
};

// Delete an Admin
const deleteAdmin = async (req, res) => {
  const { id } = req.params;

  try {
    const admin = await User.findById(id);

    if (!admin) {
      return res.status(404).json({ message: 'Admin not found' });
    }

    if (admin.role !== 'admin') {
      return res.status(400).json({ message: 'Only admins can be deleted' });
    }

    await admin.remove();
    res.json({ message: 'Admin deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting admin' });
  }
};

module.exports = { adminLogin, getAdmins, deleteAdmin,createAdmin };
