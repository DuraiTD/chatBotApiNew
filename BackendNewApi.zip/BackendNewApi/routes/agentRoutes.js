const express = require('express');
const Agent = require('../models/agentModel');
const { createAgent } = require('../controllers/agentController');
const router = express.Router();

router.post('/agent', createAgent);

module.exports = router;
