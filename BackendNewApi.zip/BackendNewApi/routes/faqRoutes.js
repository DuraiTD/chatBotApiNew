// routes/faqRoutes.js
const express = require('express');
const faqController = require('../controllers/faqController');

const router = express.Router();

// Routes for managing FAQs
router.get('/api/faqs', faqController.getAllFaqs); // Get all FAQs
router.post('/api/faqs', faqController.addFaq); // Add a new FAQ
router.put('/api/faqs/:id', faqController.updateFaq); // Update an FAQ
router.delete('/api/faqs/:id', faqController.deleteFaq); // Delete an FAQ
router.get('/api/faqs/v1', faqController.getChatResponse);

module.exports = router;
