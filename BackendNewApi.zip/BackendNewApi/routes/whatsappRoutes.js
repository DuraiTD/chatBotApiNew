const express = require("express");
const { handleWhatsAppWebhook } = require("../controllers/whatsappController");

const router = express.Router();

// WhatsApp Webhook Route
router.post("/webhook", handleWhatsAppWebhook);

module.exports = router;
