const express = require('express');
const { adminLogin, getAdmins, deleteAdmin,createAdmin } = require('../controllers/adminController');
const router = express.Router();

// Admin Login Route
router.post('/login', adminLogin);

router.post('/create-admin', createAdmin);

// Admin CRUD Routes
router.get('/admins', getAdmins); // Get all admins
router.delete('/admins/:id', deleteAdmin); // Delete a specific admin by ID

module.exports = router;
