import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import Avatar from '@mui/material/Avatar';
import Tooltip from '@mui/material/Tooltip';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import MenuIcon from '@mui/icons-material/Menu';

const settings = ['Profile', 'Account', 'Dashboard', 'Logout'];

function ResponsiveAppBar() {
  const [anchorElUser, setAnchorElUser] = React.useState(null);

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  return (
    <AppBar position="fixed" sx={{ boxShadow: '0px 4px 12px rgba(0,0,0,0.2)' }}>
      <Container maxWidth="xl">
        <Toolbar disableGutters>
          {/* ChatBot Logo */}
          <img 
            src="https://w7.pngwing.com/pngs/187/685/png-transparent-robot-robot-s-wikimedia-commons-digital-image-blog-thumbnail.png" 
            alt="ChatBot Logo"
            style={{
              width: '50px', 
              height: '40px', 
              marginRight: '20px',
              borderRadius: '50%',
              border: '3px solid #fff',
              boxShadow: '0px 4px 12px rgba(0,0,0,0.1)',
              transform: 'scale(1.1)', // Slightly enlarge the logo
              transition: 'transform 0.3s ease',
            }}
            onMouseEnter={(e) => e.target.style.transform = 'scale(1.2)'} // Add hover effect
            onMouseLeave={(e) => e.target.style.transform = 'scale(1.1)'}
          />

          {/* Welcome to Admin Dashboard */}
          <Typography
            variant="h6"
            noWrap
            sx={{
              display: 'flex',
              flexGrow: 1,
              fontFamily: 'Roboto',
              fontWeight: 1000,
              color: 'inherit',
              textDecoration: 'none',
              justifyContent: 'center',
            }}
          >
            Welcome to Admin Dashboard
          </Typography>

          {/* Profile Icon on the Right */}
          <Box sx={{ flexGrow: 0 }}>
            <Tooltip title="Open settings">
              <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                <Avatar alt="Profile" src="/static/images/avatar/2.jpg" />
              </IconButton>
            </Tooltip>
            <Menu
              sx={{ mt: '45px' }}
              id="menu-appbar"
              anchorEl={anchorElUser}
              anchorOrigin={{
                vertical: 'top',
                horizontal: 'right',
              }}
              keepMounted
              transformOrigin={{
                vertical: 'top',
                horizontal: 'right',
              }}
              open={Boolean(anchorElUser)}
              onClose={handleCloseUserMenu}
            >
              {settings.map((setting) => (
                <MenuItem key={setting} onClick={handleCloseUserMenu}>
                  <Typography sx={{ textAlign: 'center' }}>{setting}</Typography>
                </MenuItem>
              ))}
            </Menu>
          </Box>
        </Toolbar>
      </Container>
    </AppBar>
  );
}

export default ResponsiveAppBar;
