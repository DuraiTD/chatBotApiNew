import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Box, List, ListItem, ListItemButton, ListItemIcon, ListItemText, Divider, Collapse } from '@mui/material';
import DashboardIcon from '@mui/icons-material/Dashboard';
import PeopleIcon from '@mui/icons-material/People';
import AccountBoxIcon from '@mui/icons-material/AccountBox';
import SettingsIcon from '@mui/icons-material/Settings';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';  // FAQ icon
import ChatIcon from '@mui/icons-material/Chat';  // Chatbot icon
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import HistoryIcon from '@mui/icons-material/History';  // Chat History icon

const Sidebar = () => {
  const [openInternal, setOpenInternal] = useState(false);

  const handleInternalMenuToggle = () => {
    setOpenInternal(!openInternal);
  };

  return (
    <Box
      sx={{
        position: 'fixed',
        top: 0,
        left: 0,
        height: '100%',
        width: 250,
        backgroundColor: 'background.paper',
        boxShadow: 2,
        paddingTop: 10,
      }}
    >
      <List>
        <ListItem disablePadding>
          <ListItemButton component={Link} to="/admin-dashboard">
            <ListItemIcon>
              <DashboardIcon />
            </ListItemIcon>
            <ListItemText primary="Dashboard" />
          </ListItemButton>
        </ListItem>

        <ListItem disablePadding>
          <ListItemButton component={Link} to="/client-management">
            <ListItemIcon>
              <PeopleIcon />
            </ListItemIcon>
            <ListItemText primary="Clients" />
          </ListItemButton>
        </ListItem>

        <ListItem disablePadding>
          <ListItemButton component={Link} to="/agents">
            <ListItemIcon>
              <AccountBoxIcon />
            </ListItemIcon>
            <ListItemText primary="Agents" />
          </ListItemButton>
        </ListItem>

        {/* Internal Menu */}
        <ListItem disablePadding>
          <ListItemButton onClick={handleInternalMenuToggle}>
            <ListItemIcon>
              <SettingsIcon />
            </ListItemIcon>
            <ListItemText primary="Internal" />
            {openInternal ? <ExpandLess /> : <ExpandMore />}
          </ListItemButton>
        </ListItem>

        <Collapse in={openInternal} timeout="auto" unmountOnExit>
          <List component="div" disablePadding>
            <ListItem disablePadding>
              <ListItemButton component={Link} to="/internal/faq-management">
                <ListItemIcon>
                  <HelpOutlineIcon />
                </ListItemIcon>
                <ListItemText primary="FAQ Management" />
              </ListItemButton>
            </ListItem>

            {/* Chatbot Menu Item */}
            <ListItem disablePadding>
              <ListItemButton component={Link} to="/internal/chatbot">
                <ListItemIcon>
                  <ChatIcon />
                </ListItemIcon>
                <ListItemText primary="Chatbot" />
              </ListItemButton>
            </ListItem>

            {/* Chat History Menu Item */}
            <ListItem disablePadding>
              <ListItemButton component={Link} to="/internal/chat-history">
                <ListItemIcon>
                  <HistoryIcon />
                </ListItemIcon>
                <ListItemText primary="Chat History" />
              </ListItemButton>
            </ListItem>
          </List>
        </Collapse>

        <Divider />
      </List>
    </Box>
  );
};

export default Sidebar;
