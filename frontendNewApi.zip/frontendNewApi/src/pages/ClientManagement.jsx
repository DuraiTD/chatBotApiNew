import React, { useState } from 'react';
import { 
  Grid, TextField, Button, Box, Table, TableBody, TableCell, 
  TableContainer, TableHead, TableRow, Paper, Menu, MenuItem, Typography 
} from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import IconButton from '@mui/material/IconButton';

const sampleClients = [
  { id: 1, name: 'John Doe', mobile: '1234567890', email: 'johndoe@example.com', agent: 'Agent 1' },
  { id: 2, name: 'Jane Smith', mobile: '9876543210', email: 'janesmith@example.com', agent: 'Agent 2' },
  { id: 3, name: 'Sam Wilson', mobile: '5551234567', email: 'samwilson@example.com', agent: 'Agent 3' },
];

const ClientManagement = () => {
  const [clients, setClients] = useState(sampleClients);
  const [searchTerm, setSearchTerm] = useState('');
  const [newClientMenu, setNewClientMenu] = useState(null);
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedClient, setSelectedClient] = useState(null);

  const filteredClients = clients.filter(client =>
    client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.mobile.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Menu handlers
  const handleClickMenu = (event) => {
    setNewClientMenu(event.currentTarget);
  };

  const handleCloseMenu = () => {
    setNewClientMenu(null);
  };

  const handleOpenMenu = (event, client) => {
    setAnchorEl(event.currentTarget);
    setSelectedClient(client);
  };

  const handleCloseActionMenu = () => {
    setAnchorEl(null);
    setSelectedClient(null);
  };

  // Client actions
  const addNewClient = () => {
    const clientId = clients.length + 1;
    const newClient = {
      id: clientId,
      name: `Client ${clientId}`,
      mobile: '0000000000',
      email: 'newclient@example.com',
      agent: 'Unassigned'
    };
    setClients([...clients, newClient]);
    handleCloseMenu();
  };

  const handleEditClient = (id) => {
    console.log(`Edit client with ID: ${id}`);
    handleCloseActionMenu();
  };

  const handleDeleteClient = (id) => {
    setClients(clients.filter(client => client.id !== id));
    handleCloseActionMenu();
  };

  return (
    <Box sx={{ 
      padding: 3,
      marginLeft: '240px',
      width: 'calc(100% - 240px)',
      border: '1px solid #ddd',  // Added border around content for neatness
      borderRadius: '8px',        // Rounded corners for overall neat look
    }}>
      <Typography variant="h4" gutterBottom>
        Client Management
      </Typography>

      <Grid container spacing={2} sx={{ marginBottom: 2 }}>
        <Grid item xs={12} md={9}>
          <TextField
            label="Search Clients"
            variant="outlined"
            fullWidth
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            sx={{ 
              border: '1px solid #ccc', 
              borderRadius: '4px',
              '& .MuiOutlinedInput-root': {
                padding: '10px 14px', 
              },
              '& .MuiInputLabel-root': {
                fontSize: '1.1rem',
              }
            }}
          />
        </Grid>
        <Grid item xs={12} md={3} sx={{ display: 'flex', justifyContent: 'flex-end' }}>
          <Button variant="contained" color="primary" onClick={handleClickMenu}>
            Add Client
          </Button>
          <Menu
            anchorEl={newClientMenu}
            open={Boolean(newClientMenu)}
            onClose={handleCloseMenu}
          >
            <MenuItem onClick={addNewClient}>Add New Client</MenuItem>
          </Menu>
        </Grid>
      </Grid>

      <TableContainer 
        component={Paper} 
        sx={{ 
          width: '100%',
          overflowX: 'auto',
          maxWidth: 'calc(100vw - 260px)',
          marginLeft: 'auto',
          borderRadius: '8px', // Round the table corners
          border: '1px solid #ddd' // Add border for the table
        }}
      >
        <Table sx={{ minWidth: 900 }}>
          <TableHead>
            <TableRow sx={{ backgroundColor: '#1976d2' }}>
              <TableCell sx={{ fontWeight: 'bold', color: 'white', minWidth: 200 }}>Client Name</TableCell>
              <TableCell sx={{ fontWeight: 'bold', color: 'white', minWidth: 150 }}>Mobile Number</TableCell>
              <TableCell sx={{ fontWeight: 'bold', color: 'white', minWidth: 250 }}>Email ID</TableCell>
              <TableCell sx={{ fontWeight: 'bold', color: 'white', minWidth: 160 }}>Assign Agent</TableCell>
              <TableCell sx={{ fontWeight: 'bold', color: 'white', minWidth: 90 }} align="center">Actions</TableCell>
            </TableRow>
          </TableHead>

          <TableBody>
            {filteredClients.map((client) => (
              <TableRow key={client.id}>
                <TableCell>{client.name}</TableCell>
                <TableCell>{client.mobile}</TableCell>
                <TableCell>{client.email}</TableCell>
                <TableCell sx={{ minWidth: 160, padding: '6px' }}>
                  <TextField
                    select
                    value={client.agent}
                    onChange={(e) => {
                      const updatedClients = clients.map((c) =>
                        c.id === client.id ? { ...c, agent: e.target.value } : c
                      );
                      setClients(updatedClients);
                    }}
                    variant="outlined"
                    size="small"
                    sx={{ 
                      width: 140,
                      '& .MuiInputBase-root': {
                        padding: '6px 8px',
                        fontSize: '0.9rem'
                      }
                    }}
                  >
                    <MenuItem value="Agent 1">Agent 1</MenuItem>
                    <MenuItem value="Agent 2">Agent 2</MenuItem>
                    <MenuItem value="Agent 3">Agent 3</MenuItem>
                  </TextField>
                </TableCell>
                <TableCell align="center" sx={{ padding: '4px' }}>
                  <IconButton
                    onClick={(e) => handleOpenMenu(e, client)}
                    sx={{ padding: '4px' }}
                  >
                    <MoreVertIcon />
                  </IconButton>
                  <Menu
                    anchorEl={anchorEl}
                    open={Boolean(anchorEl) && selectedClient?.id === client.id}
                    onClose={handleCloseActionMenu}
                  >
                    <MenuItem onClick={() => handleEditClient(client.id)}>
                      Edit
                    </MenuItem>
                    <MenuItem onClick={() => handleDeleteClient(client.id)}>
                      Delete
                    </MenuItem>
                  </Menu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default ClientManagement;
