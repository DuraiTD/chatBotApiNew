import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Box, Button, TextField, Grid, Typography, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Paper, Modal, IconButton, MenuItem
} from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';

const FAQManagement = () => {
  const [faqs, setFaqs] = useState([]);
  const [openModal, setOpenModal] = useState(false);
  const [isEdit, setIsEdit] = useState(false);
  const [selectedFaq, setSelectedFaq] = useState(null);
  const [newFaq, setNewFaq] = useState({ question: '', answer: '', questionType: '', options: [] });
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchFAQs();
  }, []);

  // Fetch FAQs from backend API
  const fetchFAQs = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/faqs'); // Replace with your backend API URL
      setFaqs(response.data);
    } catch (error) {
      console.error('Error fetching FAQs:', error);
    }
  };

  // Handle adding a new FAQ
  const handleAddFaq = async () => {
    if (newFaq.question && newFaq.answer && newFaq.questionType) {
      try {
        const response = await axios.post('http://localhost:5000/api/faqs', newFaq);
        setFaqs([...faqs, response.data]);
        setNewFaq({ question: '', answer: '', questionType: '', options: [] });
        setOpenModal(false);
      } catch (error) {
        console.error('Error adding FAQ:', error);
      }
    }
  };

  // Handle editing an FAQ
  const handleEditFaq = async () => {
    if (newFaq.question && newFaq.answer && newFaq.questionType) {
      try {
        const response = await axios.put(`http://localhost:5000/api/faqs/${selectedFaq._id}`, newFaq);
        setFaqs(faqs.map(f => f._id === selectedFaq._id ? response.data : f));
        setNewFaq({ question: '', answer: '', questionType: '', options: [] });
        setOpenModal(false);
      } catch (error) {
        console.error('Error editing FAQ:', error);
      }
    }
  };

  // Handle deleting an FAQ
  const handleDeleteFaq = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/faqs/${id}`);
      setFaqs(faqs.filter(faq => faq._id !== id));
    } catch (error) {
      console.error('Error deleting FAQ:', error);
    }
  };

  // Open modal for adding or editing FAQ
  const openModalForEdit = (faq) => {
    setSelectedFaq(faq);
    setNewFaq({ question: faq.question, answer: faq.answer, questionType: faq.questionType, options: faq.options });
    setIsEdit(true);
    setOpenModal(true);
  };

  // Filter FAQs based on the search term
  const filteredFaqs = faqs.filter(faq =>
    faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
    faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', overflow: 'hidden' }}>
      {/* Sidebar Component */}
      <Box sx={{ width: '240px', backgroundColor: '#f4f4f4', padding: 2, position: 'fixed', height: '100vh' }}>
        <Typography variant="h6">Sidebar</Typography>
        {/* Sidebar links and other components */}
      </Box>

      {/* Main Content Area */}
      <Box sx={{
        width: '1100px', height: '70vh', overflowY: 'auto', marginLeft: '240px', padding: 3, border: '1px solid #ddd', borderRadius: 2, backgroundColor: 'white',
        boxShadow: 3,
        position: 'relative'
      }}>
        <Typography variant="h4" gutterBottom>FAQ Management</Typography>

        {/* Search Bar */}
        <Grid container spacing={2} sx={{ marginBottom: 2 }}>
          <Grid item xs={12} md={9}>
            <TextField
              label="Search FAQs"
              variant="outlined"
              fullWidth
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </Grid>
          <Grid item xs={12} md={3} sx={{ display: 'flex', justifyContent: 'flex-end' }}>
            <Button variant="contained" color="primary" onClick={() => { setIsEdit(false); setOpenModal(true); }}>
              Add FAQ
            </Button>
          </Grid>
        </Grid>

        {/* FAQ Table */}
        <TableContainer component={Paper}>
          <Table sx={{ minWidth: 900 }}>
            <TableHead>
              <TableRow sx={{ backgroundColor: '#1976d2' }}>
                <TableCell sx={{ fontWeight: 'bold', color: 'white', minWidth: 200 }}>Question</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: 'white', minWidth: 150 }}>Answer</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: 'white', minWidth: 90 }} align="center">Question Type</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: 'white', minWidth: 90 }} align="center">Options</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: 'white', minWidth: 90 }} align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredFaqs.map((faq) => (
                <TableRow key={faq._id}>
                  <TableCell>{faq.question}</TableCell>
                  <TableCell>{faq.answer}</TableCell>
                  <TableCell>{faq.questionType}</TableCell>
                  <TableCell>{faq.options.join(', ')}</TableCell> {/* Show options here */}
                  <TableCell align="center">
                    <IconButton onClick={() => openModalForEdit(faq)}>
                      <MoreVertIcon />
                    </IconButton>
                    <IconButton onClick={() => handleDeleteFaq(faq._id)} sx={{ color: 'red' }}>
                      <MoreVertIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Modal for Adding/Editing FAQ */}
        <Modal
          open={openModal}
          onClose={() => setOpenModal(false)}
          sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}
        >
          <Box sx={{
            backgroundColor: 'white', padding: 3, borderRadius: 2, maxWidth: 600, width: '100%',
            boxShadow: 24
          }}>
            <Typography variant="h6" gutterBottom>
              {isEdit ? 'Edit FAQ' : 'Add FAQ'}
            </Typography>
            <TextField
              label="Question"
              variant="outlined"
              fullWidth
              value={newFaq.question}
              onChange={(e) => setNewFaq({ ...newFaq, question: e.target.value })}
              sx={{ marginBottom: 2 }}
            />
            <TextField
              label="Answer"
              variant="outlined"
              fullWidth
              value={newFaq.answer}
              onChange={(e) => setNewFaq({ ...newFaq, answer: e.target.value })}
              sx={{ marginBottom: 2 }}
            />
            <TextField
              select
              label="Question Type"
              variant="outlined"
              fullWidth
              value={newFaq.questionType}
              onChange={(e) => setNewFaq({ ...newFaq, questionType: e.target.value })}
              sx={{ marginBottom: 2 }}
            >
              <MenuItem value="button">Button</MenuItem>
              <MenuItem value="checkbox">Checkbox</MenuItem>
              <MenuItem value="text">Text</MenuItem>
            </TextField>
            {newFaq.questionType && (newFaq.questionType === 'button' || newFaq.questionType === 'checkbox') && (
              <TextField
                label="Options (comma separated)"
                variant="outlined"
                fullWidth
                value={newFaq.options.join(', ')}
                onChange={(e) => setNewFaq({ ...newFaq, options: e.target.value.split(',').map(opt => opt.trim()) })}
                sx={{ marginBottom: 2 }}
              />
            )}

            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Button
                  fullWidth
                  variant="contained"
                  color="primary"
                  onClick={isEdit ? handleEditFaq : handleAddFaq}
                >
                  {isEdit ? 'Save Changes' : 'Add FAQ'}
                </Button>
              </Grid>
              <Grid item xs={6}>
                <Button
                  fullWidth
                  variant="outlined"
                  color="secondary"
                  onClick={() => setOpenModal(false)}
                >
                  Cancel
                </Button>
              </Grid>
            </Grid>
          </Box>
        </Modal>
      </Box>
    </Box>
  );
};

export default FAQManagement;
