import React, { useState } from 'react';
import axios from 'axios';
import { TextField, Button, Box, Typography, Avatar } from '@mui/material';

const ChatHistory = () => {
  const [clientNumber, setClientNumber] = useState('');
  const [chatHistory, setChatHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Function to handle the search
  const handleSearch = async () => {
    if (!clientNumber) {
      setError('Client number is required');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      const response = await axios.get(`http://localhost:5000/api/chat/${clientNumber}`);
      
      if (response.data && response.data.messages) {
        setChatHistory(response.data.messages); // Set the messages array into the state
      } else {
        setError('No chat history found');
      }
    } catch (err) {
      setError('Failed to fetch chat history');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ padding: '80px 80px 80px', backgroundColor: '#f8f9fa', minHeight: '70vh' }}>
      {/* Heading */}
      <Typography variant="h4" align="center" sx={{ marginBottom: 3, fontWeight: 'bold', color: '#3b5998' }}>
        Chat History
      </Typography>

      {/* Search bar */}
      <Box sx={{ display: 'flex', justifyContent: 'center', marginBottom: 3 }}>
        <TextField
          label="Enter Client Number"
          variant="outlined"
          fullWidth
          value={clientNumber}
          onChange={(e) => setClientNumber(e.target.value)}
          sx={{
            width: '100%',
            borderRadius: '20px',
            marginRight: 2,
            '& .MuiOutlinedInput-root': {
              '& fieldset': {
                borderRadius: '20px',
              },
            },
          }}
        />
        <Button
          variant="contained"
          color="primary"
          onClick={handleSearch}
          disabled={loading}
          sx={{
            padding: '10px 20px',
            borderRadius: '20px',
            fontSize: '16px',
            textTransform: 'none',
            backgroundColor: '#0078d4',
            '&:hover': {
              backgroundColor: '#005c99',
            },
          }}
        >
          {loading ? 'Loading...' : 'Search'}
        </Button>
      </Box>

      {/* Error message */}
      {error && <Typography color="error" align="center">{error}</Typography>}

      {/* Display chat history */}
      <Box sx={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        maxHeight: '60vh', 
        overflowY: 'auto', 
        padding: '0 20px',
        marginTop: '20px',
        borderRadius: '10px', 
        backgroundColor: '#fff',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
        width: '100%',
        flexDirection: 'column'
      }}>
        <Box sx={{
          width: '90%',
          maxHeight: '100%',
          overflowY: 'scroll',
          marginTop: '20px',  // Added margin to top of container
          padding: '10px 20px', // Added padding inside the container
        }}>
          {chatHistory.length > 0 ? (
            chatHistory.map((message, index) => (
              <Box
                key={message._id}
                sx={{
                  display: 'flex',
                  flexDirection: message.sender === 'Client' || message.sender === 'POEMSBOT' ? 'row-reverse' : 'row',
                  marginBottom: 2,
                  justifyContent: 'flex-start',
                  alignItems: 'center',
                }}
              >
                {/* Profile pic */}
                <Avatar
                  sx={{
                    width: 40,
                    height: 40,
                    marginLeft: message.sender === 'Client' || message.sender === 'POEMSBOT' ? '10px' : '0',
                    marginRight: message.sender === 'Client' || message.sender === 'POEMSBOT' ? '0' : '10px',
                    backgroundColor: message.sender === 'Client' ? '#ff9800' : message.sender === 'POEMSBOT' ? '#3b5998' : '#4caf50', // Green for other sender
                  }}
                >
                  {message.sender === 'Client' ? 'C' : message.sender === 'POEMSBOT' ? 'P' : 'A'}
                </Avatar>

                {/* Message */}
                <Box sx={{
                  maxWidth: '60%',
                  padding: '10px',
                  borderRadius: '10px',
                  backgroundColor: message.sender === 'Client' ? '#d1ecf1' : message.sender === 'POEMSBOT' ? '#0078d4' : '#4caf50', // Blue for POEMSBOT, Green for others
                  color: message.sender === 'Client' ? '#000' : '#fff',
                  wordWrap: 'break-word',
                  whiteSpace: 'pre-wrap',
                  overflowWrap: 'break-word',
                }}>
                  <Typography variant="body1" sx={{ fontWeight: 'bold', marginBottom: '5px' }}>
                    {message.sender}
                  </Typography>
                  <Typography variant="body2">{message.message}</Typography>
                </Box>
              </Box>
            ))
          ) : (
            // No chat history
            !loading && <Typography align="center" sx={{ fontSize: '18px', marginTop: '20px' }}>No chat history available</Typography>
          )}
        </Box>
      </Box>
    </Box>
  );
};

export default ChatHistory;
