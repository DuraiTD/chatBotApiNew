import React, { useEffect, useRef } from 'react';
import ResponsiveAppBar from './ResponsiveAppBar';  // Import the AppBar
import Sidebar from './Sidebar';  // Import the Sidebar
import { Box, Container, Grid, Paper, Typography, Card, CardContent } from '@mui/material';  // Import Material-UI components
import { Line, Bar, Pie } from 'react-chartjs-2';  // Import charting library
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, BarElement, LineElement, Title, Tooltip, Legend } from 'chart.js';

// Register necessary chart components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  BarElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

// Example chart data
const chartData = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
  datasets: [
    {
      label: 'Clients Active',
      data: [50, 70, 65, 80, 90, 120],
      fill: false,
      borderColor: 'rgba(75, 192, 192, 1)',
      tension: 0.1,
    },
    {
      label: 'Agents Active',
      data: [40, 60, 55, 75, 85, 110],
      fill: false,
      borderColor: 'rgba(153, 102, 255, 1)',
      tension: 0.1,
    },
  ],
};

// Example data for agent-client relationship (Number of clients per agent)
const agentClientData = {
  labels: ['Agent 1', 'Agent 2', 'Agent 3', 'Agent 4', 'Agent 5'],
  datasets: [
    {
      label: 'Clients Per Agent',
      data: [10, 25, 15, 35, 20],
      backgroundColor: 'rgba(255, 159, 64, 0.2)',
      borderColor: 'rgba(255, 159, 64, 1)',
      borderWidth: 1,
    },
  ],
};

// Example data for chat history (Number of messages per week)
const chatHistoryData = {
  labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
  datasets: [
    {
      label: 'Messages Sent',
      data: [120, 150, 180, 210],
      fill: false,
      borderColor: 'rgba(255, 99, 132, 1)',
      tension: 0.1,
    },
  ],
};

const AdminDashboard = () => {
  const chartRef = useRef(null); // Ref for the chart

  useEffect(() => {
    if (chartRef.current) {
      const chartInstance = new ChartJS(chartRef.current, {
        type: 'line', // or 'bar', depending on the chart type
        data: chartData,
        options: {
          responsive: true,
          plugins: {
            legend: {
              position: 'top',
            },
            tooltip: {
              mode: 'index',
              intersect: false,
            },
          },
        },
      });

      return () => {
        chartInstance.destroy(); // Clean up on unmount to avoid memory leaks
      };
    }
  }, []); // Empty dependency array to run once after mount

  return (
    <Box sx={{ display: 'flex' }}>
      {/* Fixed Sidebar */}
      <Sidebar />

      {/* Main Content Area */}
      <Box
        sx={{
          marginLeft: '250px', // to ensure content doesn't overlap sidebar
          paddingTop: '100px',  // Reduced top margin to avoid excessive hiding
          flexGrow: 1,
          padding: 3,
        }}
      >
        {/* AppBar */}
        <ResponsiveAppBar />

        {/* Admin Dashboard Content */}
        <Container sx={{ marginTop: 40 }}>
          <Typography variant="h3" gutterBottom>
            Welcome to the Admin Dashboard
          </Typography>
          <Typography 
  variant="body1" 
  paragraph 
  sx={{
    fontWeight: 'bold', 
    color: 'primary.main', // You can change this to any color from the Material-UI palette
    fontSize: '25px',     // Optional: slightly increase the font size for better visibility
  }}
>
  Here you can Manage Clients, Agents, Trading data, and Track chatbot performance.
</Typography>

          {/* Updated Grid for Stats: Number of Clients, Agents, and Agent-Client Relationship */}
          <Grid container spacing={4} justifyContent="center">
            <Grid item xs={12} sm={4}>
              <Card sx={{ boxShadow: 3, borderRadius: 2, height: '100%' }}>
                <CardContent>
                  <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
                    Total Clients
                  </Typography>
                  <Typography variant="h4" color="primary" sx={{ marginTop: 2 }}>
                    320
                  </Typography>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} sm={4}>
              <Card sx={{ boxShadow: 3, borderRadius: 2, height: '100%' }}>
                <CardContent>
                  <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
                    Total Agents
                  </Typography>
                  <Typography variant="h4" color="secondary" sx={{ marginTop: 2 }}>
                    15
                  </Typography>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} sm={4}>
              <Card sx={{ boxShadow: 3, borderRadius: 2, height: '100%' }}>
                <CardContent>
                  <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
                    Clients Per Agent
                  </Typography>
                  <Typography variant="h4" color="success.main" sx={{ marginTop: 2 }}>
                    25
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          {/* Grid for Charts */}
          <Grid container spacing={4} sx={{ marginTop: 4 }}>
            {/* Chart 1: Client and Agent Activity */}
            <Grid item xs={12} md={6}>
              <Paper sx={{ padding: 3, boxShadow: 2, borderRadius: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Client vs Agent Activity (6 Months)
                </Typography>
                <canvas ref={chartRef} />
              </Paper>
            </Grid>

            {/* Chart 2: Agent-Client Relationship */}
            <Grid item xs={12} md={6}>
              <Paper sx={{ padding: 3, boxShadow: 2, borderRadius: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Clients Per Agent (Bar Chart)
                </Typography>
                <Bar data={agentClientData} />
              </Paper>
            </Grid>

            {/* Chart 3: Chat History */}
            <Grid item xs={12} md={6}>
              <Paper sx={{ padding: 3, boxShadow: 2, borderRadius: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Chatbot Messages Sent (Weekly)
                </Typography>
                <Line data={chatHistoryData} />
              </Paper>
            </Grid>
            <Grid item xs={12} md={6}>
              <Paper sx={{ padding: 3, boxShadow: 2, borderRadius: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Clients Per Agent (Line Chart)
                </Typography>
                <Bar data={agentClientData} />
              </Paper>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </Box>
  );
};

export default AdminDashboard;
