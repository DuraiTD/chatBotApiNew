import React from 'react';

const AgentDashboard = () => {
  return (
    <div>
      <h1>Welcome to the Agent Dashboard</h1>
      {/* Add content specific to the agent here */}
    </div>
  );
};

export default AgentDashboard;
