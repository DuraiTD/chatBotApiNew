import React, { useState } from "react";
import { FaRobot, FaUser } from "react-icons/fa";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPaperPlane } from "@fortawesome/free-solid-svg-icons";
import axios from "axios"; // Import Axios
import "../App.css";

function ChatApp() {
  const [messages, setMessages] = useState([
    { sender: "bot", text: "Hello! How can I assist you today?" },
  ]);
  const [userInput, setUserInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null); // Handle error state

  const handleSend = async () => {
    if (userInput.trim() === "" || loading) return; // Prevent multiple sends if loading

    // Add user message
    const newMessages = [...messages, { sender: "user", text: userInput }];
    setMessages(newMessages);
    setUserInput("");
    setLoading(true);
    setError(null);

    console.log("Sending message:", userInput);  // Log the message being sent

    try {
      // Get bot response from /whatsapp/webhook
      const botResponse = await getChatResponse(userInput);
      console.log("Bot response received:", botResponse);

      // Add bot response to messages
      setMessages([...newMessages, { sender: "bot", text: botResponse.message }]);

      // Send message to WhatsApp (backend integration)
      await sendMessageToWhatsApp(userInput);
    } catch (error) {
      console.error("Chatbot response error:", error);
      setError("Oops! Something went wrong, please try again.");
    } finally {
      setLoading(false);
    }
  };

  const getChatResponse = async (message) => {
    try {
      console.log("Fetching response from the bot API...");

      const response = await axios.post(
        "https://c6ea-223-178-83-162.ngrok-free.app/whatsapp/webhook", // Update with your correct URL
        {
          Body: message,
          From: "whatsapp:+8608207973",
        },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      console.log("Response from bot API:", response.data); // Log the response

      if (response.data.status === "success") {
        return response.data; // Return the success message directly
      } else {
        return { message: "I didn't quite get that, try again!" }; // Default message
      }
    } catch (error) {
      console.error("Error while fetching response:", error);
      return { message: "Error retrieving response." }; // Error message fallback
    }
  };

  const sendMessageToWhatsApp = async (message) => {
    try {
      console.log("Sending message to WhatsApp API...");

      await axios.post(
        "https://2714-223-178-83-162.ngrok-free.app/whatsapp/webhook", // Update with your correct URL
        {
          Body: message,
          From: "whatsapp:+918608207973",
        },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      console.log("Message sent to WhatsApp successfully.");
    } catch (error) {
      console.error("Error sending message to WhatsApp:", error);
    }
  };

  return (
    <div className="chat-container">
      <div className="chat-header">
        <FaRobot size={30} />
        <h2>Trading Assistant</h2>
      </div>
      <div className="chat-body">
        {messages.map((msg, index) => (
          <div key={index} className={`message ${msg.sender === "user" ? "user" : "bot"}`}>
            <div className="profile-pic">
              {msg.sender === "user" ? <FaUser size={25} /> : <FaRobot size={25} />}
            </div>
            <div className="message-text">{msg.text}</div>
          </div>
        ))}
        {loading && <div className="loading">Typing...</div>}
        {error && <div className="error">{error}</div>}
      </div>
      <div className="chat-input">
        <input
          type="text"
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          placeholder="Ask about stocks, trading, or crypto..."
        />
        <button onClick={handleSend} disabled={loading}>
          <FontAwesomeIcon icon={faPaperPlane} style={{ fontSize: "12px" }} />
        </button>
      </div>
    </div>
  );
}

export default ChatApp;
