import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ChatHistory = ({ clientNumber }) => {
  const [chatHistory, setChatHistory] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  
  useEffect(() => {
    // Call the function to fetch chat history when component mounts or clientNumber changes
    if (clientNumber) {
      fetchChatHistory();
    }
  }, [clientNumber]);

  // Fetch chat history from the server
  const fetchChatHistory = async () => {
    if (!clientNumber) {
      console.error('Client number is missing!');
      return;
    }

    try {
      // Dynamically create the API URL with clientNumber
      const apiUrl = `http://localhost:5000/api/chat/${clientNumber}`;
      
      const response = await axios.get(apiUrl);
      setChatHistory(response.data); // Assuming the response contains the chat history
    } catch (error) {
      console.error('Error fetching chat history:', error);
    }
  };

  // Handle search input
  const handleSearch = () => {
    // You can filter the chat history based on the search query here
    if (searchQuery) {
      const filteredChats = chatHistory.filter(chat =>
        chat.message.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setChatHistory(filteredChats);
    } else {
      fetchChatHistory(); // Re-fetch if the search query is cleared
    }
  };

  return (
    <div>
      <h1>Chat History for Client {clientNumber}</h1>

      {/* Search Bar */}
      <input
        type="text"
        placeholder="Search by message"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />
      <button onClick={handleSearch}>Search</button>

      {/* Chat History Display */}
      <div>
        {chatHistory.length === 0 ? (
          <p>No chat history found.</p>
        ) : (
          chatHistory.map((chat, index) => (
            <div key={index}>
              <div>
                <strong>{chat.sender}</strong>: {chat.message}
              </div>
              <div>{new Date(chat.timestamp).toLocaleString()}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default ChatHistory;
