import React from 'react';

const Internal = () => {
  return (
    <div>
      <h1>Internal Settings</h1>
      <p>Manage internal settings and configurations here.</p>
    </div>
  );
};

export default Internal;
