import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import AdminDashboard from './pages/AdminDashboard';
import AgentDashboard from './pages/AgentDashboard';
import ClientManagement from './pages/ClientManagement';
import Sidebar from './pages/Sidebar';
import ResponsiveAppBar from './pages/ResponsiveAppBar';
import FAQManagement from './pages/FAQManagement';
import ChatApp from './pages/ChatApp';
import ChatHistory from './pages/ChatHistory'; // Import the ChatHistory component

const App = () => {
  return (
    <Router>
      <Routes>
        {/* Route for the Login Page */}
        <Route path="/" element={<LoginPage />} />

        {/* Route for Admin Dashboard */}
        <Route path="/admin-dashboard" element={
          <>
            <ResponsiveAppBar />
            <Sidebar />
            <AdminDashboard />
          </>
        } />

        {/* Route for Agent Dashboard */}
        <Route path="/agent-dashboard" element={
          <>
            <ResponsiveAppBar />
            <Sidebar />
            <AgentDashboard />
          </>
        } />

        {/* Route for Client Management */}
        <Route path="/client-management" element={
          <>
            <ResponsiveAppBar />
            <Sidebar />
            <ClientManagement />
          </>
        } />

        {/* Route for FAQ Management under Internal */}
        <Route path="/internal/faq-management" element={
          <>
            <ResponsiveAppBar />
            <Sidebar />
            <FAQManagement />
          </>
        } />

        {/* ✅ Route for Chatbot under Internal */}
        <Route path="/internal/chatbot" element={
          <>
            <ResponsiveAppBar />
            <Sidebar />
            <ChatApp /> {/* ChatBot Component */}
          </>
        } />

        {/* ✅ Route for Chat History under Internal */}
        <Route path="/internal/chat-history" element={
          <>
            <ResponsiveAppBar />
            <Sidebar />
            <ChatHistory /> {/* Chat History Component */}
          </>
        } />
      </Routes>
    </Router>
  );
};

export default App;
