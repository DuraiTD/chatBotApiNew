import React from 'react';

const Clients = () => {
  return (
    <div>
      <h1>Clients</h1>
      <p>Manage your clients here.</p>
    </div>
  );
};

export default Clients;
